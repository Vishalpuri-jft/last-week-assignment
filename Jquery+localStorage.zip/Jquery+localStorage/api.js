//local storage

function employee(){
    this.emp = [];

    if(localStorage.length>0){
        var retrivedarr = JSON.parse(localStorage.getItem('data'))
        this.emp = [...retrivedarr]
    }

//---------------------------------------------------POST Operation------------------------------------//
    this.post = function(object){
        var promise1 = new Promise((resolve,reject)=>{
            setTimeout(()=>{
                this.emp.push(object)
                localStorage.setItem('data',JSON.stringify(this.emp));
                resolve(this.emp)
                
            },2000)
        })
        return promise1;
    }
//------------------------------------------------DELETE Operation-------------------------------------//
    this.delete = function(id){
        var promise2 = new Promise((resolve,reject)=>{
            setTimeout(()=>{
                this.emp = this.emp.filter(ele=>ele.id!=id)
                localStorage.setItem('data',JSON.stringify(this.emp));
                resolve(this.emp)
            },2000)
        })
        return promise2;
    }
//-------------------------------------------------PUT Operation-----------------------------------------//
    this.put = function(object){
        var promise3 = new Promise((resolve,reject)=>{
            setTimeout(()=>{
                console.log();
                for(let i=0;i<this.emp.length;i++){
                    if(this.emp[i].id == object.id){
                        this.emp[i].Name = object.Name
                        this.emp[i].job = object.job
                        this.emp[i].salary = object.salary
                    }
                }
                localStorage.setItem('data',JSON.stringify(this.emp));
                resolve(this.emp)
            },2000)
        })
        return promise3;
    }
//-------------------------------------------------GET Operation----------------------------------------//
    this.get = function(){
        return this.emp;
    }
}