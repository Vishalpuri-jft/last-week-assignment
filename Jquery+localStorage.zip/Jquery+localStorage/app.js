
    Names = $("#ipname")
    job = $("#ipjob")
    salary = $("#ipsalary")
    
    
    let api = new employee();
    let array = api.get();
    display(array)
    
    let val =0;
    
    if(array.length>0){
        val = array[array.length-1].id
    }
    
    $("#button").click(async()=>{
        if(Names.val().length == 0 || job.val().length == 0 || salary.val().length==0){
            alert("Enter all the Reqired Fields")
        }
        else if($("#button").html() =='add'){
            ++val
            console.log(val)
            let object = {id:val,Name:Names.val(),job:job.val(),salary:salary.val()}
            let arr = await api.post(object)
            display(arr)
            clear()   
            }
        else{
    //ye tab execute hoga jb button ki html --> update hogi
            uptodate(selectedindex)
            clear()
            }
        }
    )
        
    // for saving the index of the element which has got triggred in pressing edit
    
    let selectedindex
    
    function clear(){
        $("#ipname").val('')
        $("#ipjob").val('')
        $("#ipsalary").val('')
    }
    
    async function remove(val){
        let arr = await api.delete(val)
        display(arr)
    }
    
    function update(val){
        $("#button").html('update')
        let obj = array.find(element=>element.id==val);
        selectedindex = val
        Names.val(obj.Name)
        job.val(obj.job) 
        salary.val(obj.salary)
    }
    
    async function uptodate(val){
        let object = {id:val,Name:Names.val(),job:job.val(),salary:salary.val()}
        console.log(object);
        let arr = await api.put(object);
        display(arr)
        clear()
        $("#button").html('add')
    }
    
    function display(arr){
        $("#table").html('<tr><th>Name</th> <th>Job</th><th>Salary</th><th>Action</th></tr>' + arr.map(ele => {
            return `<tr><td> ${ele.Name} </td>
            <td> ${ele.job} </td>
            <td> ${ele.salary} </td>
            <td> <button onclick = "remove(${ele.id})"> Delete </button> <button  onclick ="update(${ele.id})" id = "update"> edit </button> 
            </tr>`
    } ).join(" "))
    }

