//It is running on 8081 port
var express = require('express');
var app = express();
app.use(express.json());

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})

app.get('/Employee', function (req, res) {
  console.log("Got a GET request for the homepage");
  res.send(Users);
})


app.post('/Employee', function (req, res) {
  console.log(req.body);
  console.log("Got a POST request for the homepage");
  Users.push(req.body)
  res.send(Users);
})


app.delete('/Employee/Delete/:id', function (req, res) {
  console.log("Got a DELETE request for /del_user");
  console.log(req.params.id);
  Users = Users.filter(emp => Number(emp.id) !== Number(req.params.id));
  res.send(Users);
})

// This responds a GET request for the /list_user page.
app.put('/Employee/Update/:id', function (req, res) {
  console.log("Got a GET request for /list_user");
  let pos = req.body;
  for(let i=0;i<Users.length;i++){
    if(Users[i].id == req.params.id){
        Users[i].Name = pos.Name
        Users[i].job = pos.job
        Users[i].salary = pos.salary
        break
  }}
  res.send(Users);
})

let Users =  [
  {
    id: 1,
    Name: "Shivangi",
    job: "Engineer",
    salary: "895600000"
  },
  {
    id: 2,
    Name: "Satendra",
    job: "SDE",
    salary: "22300000"
  }
]