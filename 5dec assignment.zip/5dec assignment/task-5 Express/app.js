Names = $("#ipname")
job = $("#ipjob")
salary = $("#ipsalary")
let arr = [];


function getarr(){
    console.log("vishal in getarr")
    var request = $.ajax({
        url: `http://localhost:8081/Employee`,
        method: "GET",
        });
        
        request.done(function(msg) {
            console.log(msg); 
            arr = [...msg]
            console.log(arr);
        
        display(arr)
        });

        request.fail(function(textStatus) {
        alert( "Request failed: " + textStatus );
        console.log("i am second call");
        });

}

getarr()
//console.log(getarr())

$("#button").click(async()=>{
    console.log("Add click ho rha hai");
    if(Names.val().length==0 || job.val().length==0 || salary.val().length==0){
        alert("Enter all the fields")
    }
    else if($("#button").html() =='add'){
        //console.log("valid for add");
        let object = {id:arr[arr.length-1].id+1,Name:$("#ipname").val(),job:$("#ipjob").val(),salary:$("#ipsalary").val()} 
        //console.log(object);  

        var request = $.ajax({
        url: `http://localhost:8081/Employee`,
        method: "POST",
        contentType: "application/json",
        data:JSON.stringify(object)
        });
        //i am adding here extra
        request.done(function(msg) {
            console.log(msg); 
            console.log(typeof(msg)+"  "+ msg);
            display(msg)
        })

        request.fail(function(textStatus) {
        alert( "Request failed: " + textStatus );
        });

        //getarr()
        clear()
    }
    else{
        console.log("hy this is me");
        //ye tab execute hoga jb button ki html --> update hogi
        uptodate(selectedid)
        clear()
    }
})

function clear(){
    $("#ipname").val('')
    $("#ipjob").val('')
    $("#ipsalary").val('')
}

async function remove(val){
    var request = $.ajax({
        url: `http://localhost:8081/Employee/Delete/${val}`,
        method: "DELETE",
        });

        request.done(function(msg) { 
            display(msg)
        });

        request.fail(function(textStatus) {
        alert( "Request failed: " + textStatus );
        });
    }

let selectedid
function update(val){
    $("#button").html('update')
    let obj = arr.find(element=>element.id==val);
    selectedid = val
    Names.val(obj.Name)
    job.val(obj.job) 
    salary.val(obj.salary)
}

async function uptodate(val){
    let object = {id:val,Name:Names.val(),job:job.val(),salary:salary.val()}
    console.log(object);

    var request = $.ajax({
        url: `http://localhost:8081/Employee/Update/${val}`,
        method: "PUT",
        data:JSON.stringify(object),
        contentType: "application/json"
        });
        
        request.done(function(msg) { 
            getarr()
            console.log(request);
        console.log(msg)
        });

        request.fail(function(textStatus) {
        alert( "Request failed: " + textStatus );
        });

        
        $("#button").html('add')
        clear()
}



function display(arr){
    $("#tablebody").html(arr.map(ele => {
        return `<tr><td> ${ele.Name} </td>
        <td> ${ele.job} </td>
        <td> ${ele.salary} </td>
        <td> <button  class = "btn btn-danger" onclick = "remove(${ele.id})"> <i class="fa-solid fa-trash"></i> </button> <button class = "btn btn-success" onclick ="update(${ele.id})" id = "update"><i class="fa-solid fa-user-pen"></i></button> 
        </tr>`
} ).join(" "))
}

