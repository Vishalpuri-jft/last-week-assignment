var http = require('http');
var fs = require('fs');

function onRequest(req,res){
    //res.writeHead(200,{'content-type':'text/plain'})
    fs.readFile("./db.json",null,(err,data)=>{
        if(err){
            res.write("file not found!");
        }else{
            res.write(data);
            res.end();
        } 
    })
// res.end();    
}
http.createServer(onRequest).listen(8001)
    