//8004 port pe chl rha h ye


var http = require('http');
var qs = require('querystring')
const host = process.env.HOST || '0.0.0.0'
var port = process.env.PORT || 8004
const url = require('url') 

http.createServer(function (req, res) {
  //res.write('Hello World---->!aka')
  const { pathname, query } = url.parse(req.url)
  
  

  console.log(req.method);

    if(req.url == '/Employee'){
      if(req.method  == 'GET'){
        console.log("here");
        res.writeHead(200, {'Content-Type': 'text/plain'});
        res.end( JSON.stringify(Users));
        
      }
      else if(req.method =='POST'){
        return handlePostReq(req, res);
      }
    }
    else if(pathname == "/Employee/Delete"){
      const { id } = qs.parse(query)
      console.log("delete line num"+ 32);
      handleDeleteReq(req,res,id);
    }
    else{
      handlePutReq(req,res);
    }
  


}).listen(port,host,(err)=>{
    console.log("server is running on port"+"8004");
    if(err){
        console.log(err);
    }
})

function handlePostReq(req, res) {
  var pos
  const { pathname } = url.parse(req.url)
  req 
  .on('data', (chunk) => {  
    chunk = JSON.parse(chunk.toString())
    pos = chunk;
  }) 
  .on('end', () => { 
    Users.push(pos)
    res.end(JSON.stringify(Users));
  })
}


function handleDeleteReq(req, res,id) {
  console.log("58",id);
  Users = Users.filter(emp => Number(emp.id) !== Number(id));
  console.log(Users);
  res.end(JSON.stringify(Users))
}


function handlePutReq(req, res) {
    
  const { pathname, query } = url.parse(req.url)
  
  const { id } = qs.parse(query)
  var pos = 0
  req 
  .on('data', (chunk) => { 
    chunk = JSON.parse(chunk.toString())
    pos = chunk
  }) 

  .on('end', () => { 
    for(let i=0;i<Users.length;i++){
      if(Users[i].id == pos.id){
          Users[i].Name = pos.Name
          Users[i].job = pos.job
          Users[i].salary = pos.salary
          break
  }
  res.end(JSON.stringify(Users));
  })
}


let Users =  [
    {
      id: 1,
      Name: "Vishal",
      job: "Engineer",
      salary: "895600000"
    },
    {
      id: 2,
      Name: "Naman",
      job: "SDE",
      salary: "22300000"
    }
  ]

// function getUser(){
//     return ;
// }





